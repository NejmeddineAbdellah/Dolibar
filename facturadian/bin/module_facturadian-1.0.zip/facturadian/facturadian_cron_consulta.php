<?php
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';

dol_include_once('/facturadian/class/facturadian.class.php');
dol_include_once('/facturadian/lib/facturadian_facturadian.lib.php');

// Load translation files required by the page
$langs->loadLangs(array("facturadian@facturadian", "other"));

// Get parameters
$idx 		= GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action 	= GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'facturadiancard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
//$lineid   = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new FacturaDian($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->facturadian->dir_output.'/temp/massgeneration/'.$user->idx;
$hookmanager->initHooks(array('facturadiancard', 'globalcard')); // Note that conf->hooks_modules contains array


// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

$form = new Form($db);
$formfile = new FormFile($db);

if ($action == 'grilla')
{
	//********************************************************************************

	$page = $_REQUEST['page'];
	$limit = $_REQUEST['rows'];
	$sidx = $_REQUEST['sidx'];
	$sord = $_REQUEST['sord'];
	if(!$sidx) $sidx =1;

	$sql = "SELECT * FROM ".MAIN_DB_PREFIX."facturadian_cron WHERE 1";
	//$sql.= $db->plimit(10, 0);
	$resql = $db->query($sql);
	if ($resql)
	{
		$count = $db->num_rows($resql);
	}

	if( $count > 0 ) $total_pages = ceil($count/$limit);
	else $total_pages = 0;

	if ($page > $total_pages) $page=$total_pages;

	$start = $limit*$page - $limit;
	if($start <0) $start = 0;

	if ( stristr($_SERVER["HTTP_ACCEPT"],"application/xhtml+xml") ) {
				  header("Content-type: application/xhtml+xml;charset=utf-8"); 
	} else {
			  header("Content-type: text/xml;charset=utf-8");
	}
	print "<rows>";
	print "<page>".$page."</page>";
	print "<total>".$total_pages."</total>";
	print "<records>".$count."</records>";

	$sql = "SELECT * FROM ".MAIN_DB_PREFIX."facturadian_cron WHERE 1";
	//$sql.= $db->plimit(10, 0);
	$resql = $db->query($sql);
	if ($resql) 
	{
		$num = $db->num_rows($resql);
		$i = 0;

		if ($num)
		{
			while ($i < $num)
			{
				$objp = $db->fetch_object($resql);
				print "<row id='".$objp->id."'>";
					print "<cell></cell>";
					print "<cell>".$objp->documento."</cell>";
					print "<cell>".$objp->prefijo."</cell>";
					print "<cell>".$objp->dias."</cell>";
					print "<cell>".$objp->hora."</cell>";
					print "<cell>".$objp->minuto."</cell>";
					print "<cell>".$objp->ambiente."</cell>";
					print "<cell>".$objp->cantidad."</cell>";
					print "<cell>".$objp->id."</cell>";
				print "</row>";
				$i++;
			}
			print "</rows>";
			$db->free($resql);
		}
	}
	
	//********************************************************************************
}

if ($action == 'subgrid')
{
	if ( stristr($_SERVER["HTTP_ACCEPT"],"application/xhtml+xml") ) {
				  header("Content-type: application/xhtml+xml;charset=utf-8"); 
	} else {
			  header("Content-type: text/xml;charset=utf-8");
	}

	$sql = "SELECT * FROM ".MAIN_DB_PREFIX."facturadian_cron_detalles WHERE cron = '{$_POST['id']}' ORDER BY job ASC";
	
	$resql = $db->query($sql);
	if ($resql)
	{
		$num = $db->num_rows($resql);
		$i = 0;

		if ($num)
		{
			print "<rows>";
			while ($i < $num)
			{
				$objp = $db->fetch_object($resql);
				print "<row>";
					print "<cell>".$objp->job."</cell>";
					print "<cell>".$objp->prefijo."</cell>";
					print "<cell>".$objp->detalle."</cell>";
					print "<cell>".$objp->accion."</cell>";
 
				print "</row>";
				$i++;
			}
			print "</rows>";
			$db->free($resql);
		}
	}

}

$db->close();
