<?php
//usadas en myDBC.php
define("DB_SERVER", "dolibarr.c0nifcnez7db.us-east-1.rds.amazonaws.com");
define("DB_USER", "DolibarrUser");
define("DB_PASS", "DolibarrPassword");

//usadoas en enviar_fa.php
define("PREFIJO", "llx" );
define("URLTOKEN", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/token" );
define("URLUPDATE", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/update" );
define("URLEXECUTE", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/execution" );
define("URLVERIFICAR", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/verificar" );
define("URLSUBIRS3", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/subes3" );
define("URLEMAIL", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/enviapdf" );
define("URLEVENTOS", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/updateeventos" );
define("URLPREFIJOS", "https://2jr7q76fbi.execute-api.us-east-1.amazonaws.com/prod/prefijos" );
?>

