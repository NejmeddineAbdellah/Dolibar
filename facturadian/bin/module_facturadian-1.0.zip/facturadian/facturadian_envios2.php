<?php
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/facturadian/class/facturadian.class.php');
dol_include_once('/facturadian/lib/facturadian_facturadian.lib.php');

// Load translation files required by the page
$langs->loadLangs(array("facturadian@facturadian", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'facturadiancard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
//$lineid   = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new FacturaDian($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->facturadian->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('facturadiancard', 'globalcard')); // Note that conf->hooks_modules contains array


// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

$form = new Form($db);
$formfile = new FormFile($db);
llxHeader('', $langs->trans('FacturaDian'), '');

if ($action == 'create')
{
	print load_fiche_titre($langs->trans("Enviando Docuemntos a la DIAN", $langs->transnoentitiesnoconv("FacturaDian")));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
		dol_fiche_head(array(), '');

		//********************************************************************************
		$sql = "SELECT * FROM ".MAIN_DB_PREFIX."facturadian_facturadianparametros WHERE 1"; 	
		$resql = $db->query($sql);
		if ($resql)
		{
			if($db->num_rows($resql) > 0) {
				$objp = $db->fetch_object($resql);

					$ejecutar = "php scripts/enviar_".$_REQUEST['documento'].".php ".$objp->username." ".$objp->password." ".$_REQUEST['ambiente']." ".$_REQUEST['cantidad']." ".$_REQUEST['invoice'];
					$respuesta = shell_exec($ejecutar);
					print "<br /><br />".$respuesta;

					print "<br /><br />";
					$tiempo=1;
					//Actualiza
					$ejecutar2= "echo 'php scripts/update.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta2 = shell_exec($ejecutar2);

					//Subes3
					$ejecutar3= "echo 'php scripts/pdf.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta3 = shell_exec($ejecutar3);

					//Actualiza
					$ejecutar4= "echo 'php scripts/update.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta4 = shell_exec($ejecutar4);

					//Cliente
					$ejecutar5= "echo 'php scripts/cliente.php ".$objp->username." ".$objp->password." ".$_REQUEST['ambiente']."' | at now + ".++$tiempo." minutes";
					$respuesta5 = shell_exec($ejecutar5);

					//Actualiza
					$ejecutar6= "echo 'php scripts/update.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta6 = shell_exec($ejecutar6);

					//Eventos
					$ejecutar7= "echo 'php scripts/eventos.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta7 = shell_exec($ejecutar7);
					
					print "<font color='blue'><h3>Los resultados se reflejaran en 7 minutos...</h3></font>";
			}

			if($_REQUEST['etapa'] == 'email') {
					
					//Cliente
					$ejecutar5= "php scripts/cliente.php ".$objp->username." ".$objp->password." ".$_REQUEST['ambiente'];
					$respuesta5 = shell_exec($ejecutar5);
					print "<br /><br />".$respuesta;

					print "<br /><br />";
					$tiempo=1;
					//Actualiza
					$ejecutar6= "echo 'php scripts/update.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta6 = shell_exec($ejecutar6);

					//Eventos
					$ejecutar7= "echo 'php scripts/eventos.php ".$objp->username." ".$objp->password."' | at now + ".++$tiempo." minutes";
					$respuesta7 = shell_exec($ejecutar7);
					
					print "<font color='blue'><h3>Los resultados se reflejaran en 3 minutos...</h3></font>";
			}
				
		}
		$db->free($resql);


		print "<br /><br />";
		//********************************************************************************
		

		dol_fiche_end();

	print '</form>';
}

// End of page
llxFooter();
$db->close();
